import {
  IsInt,
  IsOptional,
  IsString,
  IsNotEmpty,
  IsEmail,
  
} from 'class-validator';
import { AddressDto } from './address.dto';
export class ContactDto{
    @IsString()
    @IsOptional()
    firstName? : string;

    @IsString()
    @IsOptional()
    lastName? : string;
    
    @IsString()
    @IsOptional()
    job? : string;

    @IsString()
    mobilePhone: string;

    @IsString()
    groundPhone: string;


    @IsOptional()
    @IsEmail()
    mailBox?: string;

    @IsOptional()
    contactAddress?: AddressDto;
}